 SELECT SUM(cases) AS "total cases", SUM(deaths) AS "total deaths" FROM Covid
